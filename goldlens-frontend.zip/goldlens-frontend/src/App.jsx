import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, AreaChart, Area
} from 'recharts'
import relativeValue from './data/relativeValue.json'
import backtest from './data/backtest.json'
import termStructure from './data/termStructure.json'
import goldBars from './assets/gold-bars.jpg'
import iconLiveAnalysis from './assets/icon-live-analysis.png'
import iconTermStructure from './assets/icon-term-structure.png'
import iconBacktest from './assets/icon-backtest.png'
import logo from './assets/logo.png'

function Nav() {
  return (
    <nav className="nav">
      <div className="nav-logo">
        <img src={logo} alt="GoldLens logo" className="nav-logo-img" />
        GoldLens
      </div>
      <div className="nav-links">
        <a href="#problem">Problem</a>
        <a href="#live">Live Analysis</a>
        <a href="#term">Term Structure</a>
        <a href="#backtest">Backtest</a>
        <a href="#team">Team</a>
      </div>
      <a className="btn btn-primary" href="https://github.com/JaineshBharti5" target="_blank" rel="noreferrer" style={{ boxShadow: '4px 4px 0 0 #000', padding: '.7rem 1.4rem' }}>
        View on GitHub
      </a>
    </nav>
  )
}

function Hero() {
  return (
    <section className="stage hero" id="hero">
      <div className="dots" />
      <div className="hero-copy">
        <div className="pill">NEW: MCX Bhavcopy Auto-Normalizer</div>
        <h1>Four contracts. One metal. Real <span className="stroke">gaps</span>.</h1>
        <p>GOLDM, GOLDTEN, GOLDGUINEA and GOLDPETAL all track the same gold — but liquidity, roll timing and purity pull their prices apart. GoldLens measures exactly how far, and whether that gap is worth trading.</p>
        <div className="hero-cta">
          <a href="#live" className="btn btn-primary">See Live Analysis</a>
          <a href="#backtest" className="btn btn-secondary">View Backtest</a>
        </div>
      </div>
      <div className="mockup">
        <div className="mockup-bar">
          <div className="mockup-dot" style={{ background: '#ff5f57' }} />
          <div className="mockup-dot" style={{ background: '#febc2e' }} />
          <div className="mockup-dot" style={{ background: '#28c840' }} />
        </div>
        <div className="mockup-body mockup-body-img">
          <img
            src={goldBars}
            alt="Stacked gold bullion bars"
            className="mockup-img"
          />
        </div>
      </div>
    </section>
  )
}

function Marquee() {
  const items = ['GOLD', 'GOLDM', 'GOLDTEN', 'GOLDGUINEA', 'GOLDPETAL', 'MCX BHAVCOPY']
  const doubled = [...items, ...items]
  return (
    <div className="marquee">
      <div className="marquee-track">
        {doubled.map((t, i) => <div className="marquee-item" key={i}>{t}</div>)}
      </div>
    </div>
  )
}

function ProblemSolution() {
  const problems = [
    'Inconsistent date formats and expiry codes make raw Bhavcopy data unusable without cleanup.',
    'Thin liquidity and near-month roll artifacts create mispricing that looks tradeable but isn\u2019t.',
    'An apparent "edge" is often just gold\u2019s own price trend in disguise.',
    'Retail traders and quant desks still rely on manual spreadsheets.',
  ]
  const solutions = [
    'Auto-normalizes every contract to price-per-gram, 999 purity, on one common basis.',
    'Flags gaps only after filtering for liquidity and roll-window noise.',
    'Strips out gold\u2019s own beta before scoring a spread as a real signal.',
    'Backtests every signal cost-adjusted, walk-forward, and reports it honestly.',
  ]
  return (
    <section id="problem">
      <div className="kicker">THE PROBLEM</div>
      <h2>No tool watches the gaps between them</h2>
      <p className="lead">MCX's public Bhavcopy data is free, messy and scattered across four contract types. Nothing today normalizes it, tracks the spread, or tells a trader whether a mispricing is real or just noise.</p>
      <div className="compare">
        <div className="compare-card card-problem">
          <h3>Without GoldLens</h3>
          <ul>
            {problems.map((p, i) => (
              <li key={i}><span className="mark mark-x">✕</span>{p}</li>
            ))}
          </ul>
        </div>
        <div className="compare-card card-solution">
          <h3>With GoldLens</h3>
          <ul>
            {solutions.map((s, i) => (
              <li key={i}><span className="mark mark-check">✓</span>{s}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}

function FeatureGrid() {
  const features = [
    { icon: iconLiveAnalysis, title: 'Live Analysis', desc: 'Normalized price per gram across all five contracts, updated per session.', href: '#live' },
    { icon: iconTermStructure, title: 'Term Structure', desc: 'Annualized carry by contract, so you know exactly what contango is costing.', href: '#term' },
    { icon: iconBacktest, title: 'Backtest', desc: 'Cost-adjusted, walk-forward results — no hindsight bias, no cherry-picking.', href: '#backtest' },
  ]
  return (
    <section className="feature-section">
      <div className="kicker">WHAT'S INSIDE</div>
      <h2>One dashboard, three views</h2>
      <div className="grid3" style={{ marginTop: '2.5rem' }}>
        {features.map((f) => (
          <a className="feature-card" href={f.href} key={f.title}>
            <div className="feature-icon"><img src={f.icon} alt="" className="feature-icon-img" /></div>
            <h3>{f.title}</h3>
            <p>{f.desc}</p>
          </a>
        ))}
      </div>
    </section>
  )
}

function LiveAnalysis() {
  const symbols = ['GOLD', 'GOLDGUINEA', 'GOLDM', 'GOLDPETAL', 'GOLDTEN']
  const colors = { GOLD: '#171e19', GOLDGUINEA: '#b7c6c2', GOLDM: '#ffe17c', GOLDPETAL: '#000000', GOLDTEN: '#71717a' }
  return (
    <section id="live">
      <div className="kicker">LIVE ANALYSIS</div>
      <h2>Normalized price, per gram, 999 purity</h2>
      <p className="lead">All five gold contracts converted onto a common basis — the gaps between the lines are the mispricing GoldLens hunts for.</p>
      <div className="chart-box">
        <ResponsiveContainer width="100%" height={340}>
          <LineChart data={relativeValue}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" />
            <XAxis dataKey="date" stroke="#000" fontSize={12} />
            <YAxis stroke="#000" fontSize={12} domain={['auto', 'auto']} />
            <Tooltip contentStyle={{ background: '#fff', border: '2px solid #000' }} />
            <Legend />
            {symbols.map(s => (
              <Line key={s} type="monotone" dataKey={s} stroke={colors[s]} strokeWidth={2} dot={false} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="note">Latest flag: <strong>GOLDTEN — {relativeValue[relativeValue.length - 1].GOLDTEN_flag}</strong> for five consecutive sessions.</p>
    </section>
  )
}

function TermStructure() {
  return (
    <section id="term">
      <div className="kicker">TERM STRUCTURE</div>
      <h2>Annualized carry by contract</h2>
      <p className="lead">Every contract sits in contango — far-month pricier than near-month — but the size of that carry differs by contract.</p>
      <div className="chart-box">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={termStructure}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" />
            <XAxis dataKey="symbol" stroke="#000" fontSize={12} />
            <YAxis stroke="#000" fontSize={12} unit="%" />
            <Tooltip contentStyle={{ background: '#fff', border: '2px solid #000' }} />
            <Bar dataKey="annualizedCarryPct" fill="#ffe17c" stroke="#000" strokeWidth={2} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </section>
  )
}

function HowItWorks() {
  const steps = [
    { color: 'var(--sage)', title: 'Pull Bhavcopy', desc: 'Daily MCX Bhavcopy data ingested for all four contracts.' },
    { color: 'var(--yellow)', title: 'Normalize', desc: 'Everything converted to price-per-gram, 999 purity, common basis.' },
    { color: 'var(--white)', title: 'Flag & Backtest', desc: 'Real gaps flagged, then tested cost-adjusted and walk-forward.' },
  ]
  return (
    <section className="dark-section">
      <div className="kicker">HOW IT WORKS</div>
      <h2>From messy data to an honest signal</h2>
      <div className="steps">
        {steps.map((s, i) => (
          <div className="step" key={s.title}>
            <div className="step-circle" style={{ '--step-color': s.color }}>{i + 1}</div>
            <h4>{s.title}</h4>
            <p>{s.desc}</p>
            <div className="step-line" />
          </div>
        ))}
      </div>
    </section>
  )
}

function Backtest() {
  return (
    <section id="backtest">
      <div className="kicker">BACKTEST — COST-ADJUSTED, WALK-FORWARD</div>
      <h2>Honest results, not hopeful ones</h2>
      <div className="stats">
        <div className="stat"><b>{backtest.totalReturnPct}%</b><span>total return</span></div>
        <div className="stat"><b>{backtest.sharpeRatio}</b><span>Sharpe ratio</span></div>
        <div className="stat"><b>{backtest.winRatePct}%</b><span>win rate</span></div>
        <div className="stat"><b>{backtest.maxDrawdownPct}%</b><span>max drawdown</span></div>
      </div>
      <div className="chart-box" style={{ marginTop: '1.5rem' }}>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={backtest.cumulativeCurve}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" />
            <XAxis dataKey="date" stroke="#000" fontSize={12} />
            <YAxis stroke="#000" fontSize={12} unit="%" />
            <Tooltip contentStyle={{ background: '#fff', border: '2px solid #000' }} />
            <Area type="monotone" dataKey="value" stroke="#000" strokeWidth={2} fill="#ffe17c" fillOpacity={0.6} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <p className="note">On {backtest.tradingDays} trading days of live-collected data, the simple threshold strategy shows no edge after transaction costs — exactly the kind of result GoldLens is built to report honestly, not hide.</p>
    </section>
  )
}

function Personas() {
  const personas = [
    { cls: 'persona-sage', badge: 'RETAIL TRADER', title: 'Stop guessing the spread', desc: 'See which contract is actually mispriced today, without opening four separate charts.' },
    { cls: 'persona-yellow', badge: 'QUANT RESEARCHER', title: 'Skip the cleanup step', desc: 'Normalized, purity-adjusted data ready for your own models — no Bhavcopy wrangling.' },
    { cls: 'persona-dark', badge: 'DATA NERD', title: 'Read the backtest, not the hype', desc: 'Walk-forward, cost-adjusted results reported even when the edge disappears.' },
  ]
  return (
    <section className="persona-section">
      <div className="kicker">WHO IT'S FOR</div>
      <h2>Built for people who check their assumptions</h2>
      <div className="grid3" style={{ marginTop: '2.5rem' }}>
        {personas.map((p) => (
          <div className={`persona-card ${p.cls}`} key={p.badge}>
            <div className="persona-badge">{p.badge}</div>
            <h3>{p.title}</h3>
            <p>{p.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

function FinalCTA() {
  return (
    <section className="final-cta">
      <div className="dots" />
      <h2>See the gaps MCX doesn't show you</h2>
      <div className="hero-cta">
        <a href="#live" className="btn btn-primary">See Live Analysis</a>
        <a href="https://github.com/JaineshBharti5" target="_blank" rel="noreferrer" className="btn btn-secondary">View on GitHub</a>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer id="team">
      <div className="footer-grid">
        <div className="footer-col">
          <h4>GoldLens</h4>
          <a href="#hero">Overview</a>
          <a href="#problem">Problem</a>
        </div>
        <div className="footer-col">
          <h4>Product</h4>
          <a href="#live">Live Analysis</a>
          <a href="#term">Term Structure</a>
          <a href="#backtest">Backtest</a>
        </div>
        <div className="footer-col">
          <h4>Team</h4>
          <span>Aman Kumar — strategy & backtesting</span>
          <span>R Vishal Karthik — research & docs</span>
          <span>Jainesh Bharti — frontend & backend</span>
        </div>
      </div>
      <div className="footer-bottom">
        <div>Team 3 Musketeers — Hack in Hills '26</div>
        <div className="social">
          <a href="https://github.com/JaineshBharti5" target="_blank" rel="noreferrer">GH</a>
          <a href="#hero">↑</a>
        </div>
      </div>
    </footer>
  )
}

export default function App() {
  return (
    <>
      <Nav />
      <Hero />
      <Marquee />
      <ProblemSolution />
      <FeatureGrid />
      <LiveAnalysis />
      <TermStructure />
      <HowItWorks />
      <Backtest />
      <Personas />
      <FinalCTA />
      <Footer />
    </>
  )
}